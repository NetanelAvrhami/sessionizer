namespace sessionizer.Responses;

public class UsersResponse
{
    public Dictionary<string, HashSet<string>> UsersUniqueSitesMap { get; set; }
    
}