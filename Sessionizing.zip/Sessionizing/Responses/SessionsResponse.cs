namespace sessionizer.Responses;

public class SessionsResponse 
{
    public Dictionary<string, List<double>> UrlsSessionsMap { get; set; }


}