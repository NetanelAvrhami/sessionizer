namespace sessionizer.Models;

public class SiteAndUrl
{
    public Tuple<string, string> siteAndUrl;

    
}