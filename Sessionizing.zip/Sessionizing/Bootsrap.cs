using sessionizer.Models;
using sessionizer.Utilities;

namespace sessionizer;

public class Bootsrap
{
    private const string Input1 = "Data/input_1.csv";
    private const string Input2 = "Data/input_2.csv";
    private const string Input3 = "Data/input_3.csv";

}